import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type ColorTheme = 
  | 'white' 
  | 'blue' 
  | 'purple' 
  | 'mint' 
  | 'pink' 
  | 'orange'
  | 'indigo'
  | 'teal'
  | 'graphite';

interface ThemeState {
  colorTheme: ColorTheme;
  setColorTheme: (theme: ColorTheme) => void;
}

const colors: Record<ColorTheme, string> = {
  white: '#F2F2F7',
  blue: '#E8F3FF',
  purple: '#F2E8FF',
  mint: '#E8FFF0',
  pink: '#FFF0F6',
  orange: '#FFF4E8',
  indigo: '#EEF2FF',
  teal: '#E8FBFF',
  graphite: '#F5F5F7'
};

const darkColors: Record<ColorTheme, string> = {
  white: '#1C1C1E',
  blue: '#0A3069',
  purple: '#3B1F69',
  mint: '#0F4435',
  pink: '#69223B',
  orange: '#692B0F',
  indigo: '#1E2A69',
  teal: '#0A4659',
  graphite: '#2C2C2E'
};

const getIsDarkMode = () => {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-color-scheme: dark)').matches;
};

const updateThemeColors = (theme: ColorTheme) => {
  if (typeof document === 'undefined') return;
  
  const root = document.documentElement;
  const isDark = getIsDarkMode();
  const baseColor = isDark ? darkColors[theme] : colors[theme];

  root.style.setProperty('--theme-base', baseColor);
  root.style.setProperty('--theme-color', theme);

  const metaThemeColor = document.querySelector('meta[name="theme-color"]');
  if (metaThemeColor) {
    metaThemeColor.setAttribute('content', baseColor);
  }
};

const initializeTheme = () => {
  if (typeof document === 'undefined') return;
  
  const isDark = getIsDarkMode();
  document.documentElement.style.setProperty(
    '--theme-base',
    isDark ? darkColors.white : colors.white
  );
};

if (typeof window !== 'undefined') {
  initializeTheme();
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const currentTheme = useTheme.getState().colorTheme;
    updateThemeColors(currentTheme);
  });
}

export const useTheme = create<ThemeState>()(
  persist(
    (set) => ({
      colorTheme: 'white',
      setColorTheme: (theme) => {
        set({ colorTheme: theme });
        updateThemeColors(theme);
      },
    }),
    {
      name: 'theme-storage',
      partialize: (state) => ({ colorTheme: state.colorTheme }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          updateThemeColors(state.colorTheme);
        } else {
          updateThemeColors('white');
        }
      },
    }
  )
);