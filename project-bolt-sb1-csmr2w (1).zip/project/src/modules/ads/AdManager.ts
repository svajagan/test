import { create } from 'zustand';
import { trackAdInteraction } from '../analytics/AnalyticsManager';
import { AD_UNIT_PATH, AD_UNIT_ID, AD_TIMEOUT, AD_CONTAINER_ID, COOLDOWN_PERIOD } from './constants';
import { handleAdError } from './utils';
import { validateAdRequirements } from './utils/validation';
import { cleanupAdResources } from './utils/cleanup';
import { createAdContainer } from './utils/dom';
import type { AdStore, AdState } from './types';

const loadGPTScript = async (): Promise<void> => {
  if (window.googletag) return;
  
  return new Promise((resolve, reject) => {
    try {
      // Check if script is already being loaded
      const existingScript = document.querySelector('script[src*="securepubads.g.doubleclick.net"]');
      if (existingScript) {
        return resolve();
      }

      const script = document.createElement('script');
      script.src = 'https://securepubads.g.doubleclick.net/tag/js/gpt.js';
      script.async = true;
      script.crossOrigin = 'anonymous';
      
      script.onload = () => {
        window.googletag = window.googletag || { cmd: [] };
        window.googletag.cmd = window.googletag.cmd || [];
        resolve();
      };
      
      script.onerror = () => reject(new Error('Failed to load GPT script'));
      document.head.appendChild(script);
    } catch (error) {
      reject(new Error('Failed to initialize GPT'));
    }
  });
};

const initialState: AdState = {
  isLoading: false,
  isRewarded: false,
  lastRewardTime: null,
  error: null,
  adUnit: null,
  revenue: 0,
  impressions: 0,
  isPreloading: false,
  preloadedAd: null
};

export const useAdStore = create<AdStore>((set, get) => ({
  state: initialState,
  actions: {
    initializeAds: async () => {
      try {
        // Reset error state first
        set({ state: { ...get().state, error: null, isLoading: true } });

        // Validate requirements
        const { isValid, errors } = validateAdRequirements();
        if (!isValid) {
          throw new Error(errors.join(', '));
        }

        // Load GPT script
        await loadGPTScript();

        // Initialize GPT
        return new Promise<void>((resolve, reject) => {
          const timeout = setTimeout(() => {
            reject(new Error('GPT initialization timeout'));
          }, AD_TIMEOUT);

          window.googletag.cmd.push(() => {
            try {
              clearTimeout(timeout);

              // Enable features
              googletag.pubads().enableSingleRequest();
              googletag.pubads().collapseEmptyDivs();
              googletag.pubads().setCentering(true);
              googletag.enableServices();

              // Define the ad slot
              const slot = googletag
                .defineSlot(AD_UNIT_PATH, [300, 250], AD_UNIT_ID)
                ?.addService(googletag.pubads());

              if (!slot) {
                throw new Error('Failed to define ad slot');
              }

              // Add event listeners
              googletag.pubads().addEventListener('slotRenderEnded', (event) => {
                if (event.slot === slot) {
                  if (event.isEmpty) {
                    set({ state: { ...get().state, error: 'No ads available' } });
                  } else {
                    set({ state: { ...get().state, impressions: get().state.impressions + 1 } });
                    // Refresh the ad after 30 seconds
                    setTimeout(() => {
                      googletag.pubads().refresh([slot]);
                    }, 30000);
                  }
                }
              });

              googletag.pubads().addEventListener('impressionViewable', (event) => {
                if (event.slot === slot) {
                  trackAdInteraction('display', 'complete');
                }
              });

              // Display the ad
              googletag.display(AD_UNIT_ID);
              googletag.pubads().refresh([slot]);

              set({ state: {
                ...initialState,
                adUnit: AD_UNIT_ID,
                isLoading: false
              }});

              trackAdInteraction('display', 'init');
              resolve();
            } catch (error) {
              clearTimeout(timeout);
              reject(error);
            }
          });
        });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Failed to initialize ads';
        set({ state: {
          ...initialState,
          error: errorMessage,
          isLoading: false
        }});
        trackAdInteraction('display', 'init_error');
      }
    },

    showRewardedAd: async () => {
      const { state } = get();
      
      if (state.isLoading) {
        return false;
      }

      if (state.lastRewardTime && Date.now() - state.lastRewardTime < COOLDOWN_PERIOD) {
        const remainingTime = Math.ceil((COOLDOWN_PERIOD - (Date.now() - state.lastRewardTime)) / 1000);
        set({ state: { ...state, error: `Please wait ${remainingTime} seconds` } });
        return false;
      }

      set({ state: { ...state, isLoading: true, error: null } });
      let adResources = {};

      try {
        return await new Promise<boolean>((resolve, reject) => {
          let timeoutId: number | null = null;

          const cleanup = () => {
            if (timeoutId !== null) {
              window.clearTimeout(timeoutId);
              timeoutId = null;
            }
            cleanupAdResources(adResources);
          };

          timeoutId = window.setTimeout(() => {
            cleanup();
            reject(new Error('Ad load timeout'));
          }, AD_TIMEOUT);

          try {
            const adContainer = createAdContainer(AD_CONTAINER_ID);
            adResources.container = adContainer;

            const adDiv = document.createElement('div');
            adDiv.id = AD_UNIT_ID;
            adContainer.appendChild(adDiv);

            window.googletag.cmd.push(() => {
              try {
                googletag.display(AD_UNIT_ID);

                googletag.pubads().addEventListener('impressionViewable', () => {
                  cleanup();
                  set({ 
                    state: { 
                      ...state, 
                      impressions: state.impressions + 1,
                      lastRewardTime: Date.now()
                    }
                  });
                  resolve(true);
                });

                googletag.pubads().addEventListener('slotRenderEnded', (event) => {
                  if (event.isEmpty) {
                    cleanup();
                    reject(new Error('No ad available'));
                  }
                });
              } catch (error) {
                cleanup();
                reject(error);
              }
            });
          } catch (error) {
            cleanup();
            reject(error);
          }
        });
      } catch (error) {
        cleanupAdResources(adResources);
        set({ state: { ...state, isLoading: false, error: error.message } });
        return false;
      }
    },

    resetError: () => {
      const { state } = get();
      set({ state: { ...state, error: null } });
    }
  },
}));