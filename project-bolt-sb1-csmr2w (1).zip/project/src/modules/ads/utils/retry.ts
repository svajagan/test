import { AD_RETRY_ATTEMPTS, AD_RETRY_DELAY, AD_ERROR_MESSAGES } from '../constants';

export async function retryWithBackoff<T>(
  operation: () => Promise<T>,
  maxAttempts: number = AD_RETRY_ATTEMPTS,
  baseDelay: number = AD_RETRY_DELAY
): Promise<T> {
  let lastError: Error | undefined;
  let attemptCount = 0;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      attemptCount++;
      console.debug(`Ad retry attempt ${attemptCount}/${maxAttempts}`);
      return await operation();
    } catch (error) {
      lastError = error as Error;
      if (attempt < maxAttempts - 1) {
        const delay = baseDelay * Math.pow(2, attempt) + Math.random() * 1000;
        console.debug(`Retrying ad in ${Math.round(delay/1000)}s...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  throw lastError || new Error(AD_ERROR_MESSAGES.GENERIC);
}