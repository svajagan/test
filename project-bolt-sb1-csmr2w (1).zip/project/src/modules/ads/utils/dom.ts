import { AD_CONTAINER_STYLES } from '../constants';

export function createAdContainer(id: string): HTMLDivElement {
  const container = document.createElement('div');
  container.id = id;
  
  Object.entries(AD_CONTAINER_STYLES).forEach(([property, value]) => {
    container.style[property as any] = value;
  });
  
  document.body.appendChild(container);
  return container;
}