import { AD_PRELOAD_TIMEOUT, VIDEO_AD_CLIENT, AD_ERROR_MESSAGES } from '../constants';
import { cleanupAdResources } from './cleanup';
import type { PreloadedAd } from '../types';

export async function preloadAd(): Promise<PreloadedAd> {
  return new Promise((resolve, reject) => {
    // Verify IMA SDK is available
    if (!window.google?.ima) {
      reject(new Error(AD_ERROR_MESSAGES.INIT));
      return;
    }

    const timeoutId = setTimeout(() => {
      cleanup();
      reject(new Error(AD_ERROR_MESSAGES.TIMEOUT));
    }, AD_PRELOAD_TIMEOUT);

    const adContainer = document.createElement('div');
    adContainer.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:1px;height:1px;';
    document.body.appendChild(adContainer);

    let adResources = {
      container: adContainer
    };

    try {
      const adDisplayContainer = new google.ima.AdDisplayContainer(adContainer);
      adResources.adDisplayContainer = adDisplayContainer;
      
      // Initialize container only if page is visible
      if (!document.hidden) {
        adDisplayContainer.initialize();
      }

      const adsLoader = new google.ima.AdsLoader(adDisplayContainer);
      adResources.adsLoader = adsLoader;

      let adStarted = false;
      adsLoader.addEventListener(
        google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
        (event) => {
          clearTimeout(timeoutId);
          const adsManager = event.getAdsManager({});
          resolve({
            start: async () => {
              try {
                adStarted = true;
                await adsManager.init(
                  window.innerWidth,
                  window.innerHeight,
                  window.innerWidth > window.innerHeight
                    ? google.ima.ViewMode.FULLSCREEN
                    : google.ima.ViewMode.NORMAL
                );
                await adsManager.start();
                console.debug('Ad started successfully');
                return true;
              } catch (error) {
                console.error('Ad start error:', error);
                if (!adStarted) {
                  reject(new Error(AD_ERROR_MESSAGES.GENERIC));
                }
                return false;
              }
            }
          });
        }
      );

      adsLoader.addEventListener(
        google.ima.AdErrorEvent.Type.AD_ERROR,
        (error) => {
          clearTimeout(timeoutId);
          cleanup();
          reject(error);
        }
      );

      const adsRequest = new google.ima.AdsRequest();
      adsRequest.adTagUrl = `https://googleads.g.doubleclick.net/pagead/ads?` +
        `client=${VIDEO_AD_CLIENT}` +
        `&ad_type=video_reward` +
        `&sz=640x360` +
        `&iu=/21775744923/rewarded_video_example` +
        `&env=vp` +
        `&gdfp_req=1` +
        `&output=vast` +
        `&unviewed_position_start=1` +
        `&impl=s` +
        `&url=${encodeURIComponent(window.location.href)}` +
        `&description_url=${encodeURIComponent(window.location.href)}` +
        `&correlator=${Date.now()}`;

      adsLoader.requestAds(adsRequest);
    } catch (error) {
      clearTimeout(timeoutId);
      cleanup();
      reject(error);
    }

    function cleanup() {
      cleanupAdResources(adResources);
      adResources = {};
    }
  });
}