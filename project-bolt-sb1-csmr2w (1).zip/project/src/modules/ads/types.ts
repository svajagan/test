export interface AdState {
  isLoading: boolean;
  isRewarded: boolean;
  lastRewardTime: number | null;
  error: string | null;
  adUnit: string | null;
  revenue: number;
  impressions: number;
  isPreloading: boolean;
  preloadedAd: any | null;
}

export interface PreloadedAd {
  start: () => Promise<boolean>;
}

export interface AdStore {
  state: AdState;
  actions: {
    showRewardedAd: () => Promise<boolean>;
    resetError: () => void;
    initializeAds: () => Promise<void>;
  };
}

declare global {
  interface Window {
    adsbygoogle: any;
    gtag: (...args: any[]) => void;
    google: {
      ima: {
        AdDisplayContainer: any;
        AdsLoader: any;
        AdsManagerLoadedEvent: any;
        AdsRequest: any;
        AdEvent: any;
        ViewMode: any;
        AdErrorEvent: any;
      };
    };
  }
}