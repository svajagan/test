import { AD_CONTAINER_ID, AD_TIMEOUT } from './constants';

export const isAdBlockEnabled = () => {
  try {
    return !window.gtag || !window.google?.ima;
  } catch {
    return true;
  }
};

export const cleanupAdContainer = () => {
  const container = document.getElementById(AD_CONTAINER_ID);
  if (container) {
    container.remove();
  }
};

export const handleAdError = (error: unknown): string => {
  cleanupAdContainer();
  
  if (error instanceof Error) {
    // Enhance error message based on type
    if (error.message.includes('timeout')) {
      return `Ad request timed out after ${AD_TIMEOUT/1000} seconds. Please check your connection and try again.`;
    }
    if (error.message.includes('network')) {
      return 'Network error occurred. Please check your internet connection.';
    }
    if (error.message.includes('blocked')) {
      return 'Ad blocker detected. Please disable it to watch ads.';
    }
    return `Ad error: ${error.message}`;
  }
  return 'Failed to initialize ad services';
};