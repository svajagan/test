export const COOLDOWN_PERIOD = 5 * 60 * 1000; // 5 minutes
export const AD_UNIT_PATH = '/23282275124/display';
export const AD_UNIT_ID = 'div-gpt-ad-1738907796726-0';
export const AD_TIMEOUT = 15000; // 15 seconds
export const AD_RETRY_ATTEMPTS = 3;
export const AD_RETRY_DELAY = 2000; // 2 second base delay
export const AD_CONTAINER_ID = 'ad-container';
export const AD_LOAD_TIMEOUT = 10000; // 10 seconds for initial load
export const AD_PRELOAD_TIMEOUT = 5000; // 5 seconds for preloading

export const AD_ERROR_MESSAGES = {
  TIMEOUT: 'Ad request timed out. Please check your connection and try again.',
  NETWORK: 'Unable to load ad due to network issues. Please check your connection.',
  BLOCKED: 'Ad blocker detected. Please disable it to watch ads.',
  INIT: 'Failed to initialize ad services. Please refresh the page.',
  GENERIC: 'Unable to load ad. Please try again.'
} as const;

export const AD_CONTAINER_STYLES = {
  position: 'fixed',
  zIndex: '9999',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '300px',
  height: '250px',
  background: 'white',
  borderRadius: '12px',
  boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden'
} as const;