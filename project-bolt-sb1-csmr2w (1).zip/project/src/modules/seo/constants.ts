export const SEO_CONFIG = {
  siteName: '1 Odd Out',
  titleTemplate: '🧠 %s | Best Free Brain Training Game 2024 🎮',
  defaultDescription: '🎯 Challenge your mind with 1 Odd Out, the #1 brain training puzzle game! 🧩 Test logical thinking and compete globally! ⭐',
  siteUrl: 'https://www.1oddout.com',
  twitterHandle: '@1oddout',
  defaultImage: 'https://www.1oddout.com/social-preview.jpg',
  themeColor: {
    light: '#F2F2F7',
    dark: '#1C1C1E'
  }
} as const;

export const STRUCTURED_DATA = {
  organization: {
    '@type': 'Organization',
    name: '1 Odd Out',
    description: '🧠 Challenge your mind with 1oddout - the #1 free brain training puzzle game of 2025! 🎯 Test your logic, improve pattern recognition, and compete with players worldwide! ⭐',
    url: 'https://www.1oddout.com',
    logo: 'https://www.1oddout.com/icon-512.png',
    sameAs: [
      'https://twitter.com/1oddout',
      'https://www.facebook.com/1oddout',
      'https://www.instagram.com/1oddout'
    ]
  },
  breadcrumbList: {
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Home',
        item: 'https://www.1oddout.com'
      }
    ]
  }
} as const;