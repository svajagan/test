import { STRUCTURED_DATA } from '../constants';

export function generateGameSchema(data: {
  name: string;
  description: string;
  rating?: number;
  ratingCount?: number;
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'VideoGame',
    name: data.name,
    description: data.description,
    url: 'https://www.1oddout.com',
    applicationCategory: 'Game',
    applicationSubCategory: 'Brain Training',
    operatingSystem: 'Any',
    gamePlatform: 'Web Browser',
    ...(data.rating && data.ratingCount ? {
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: data.rating,
        ratingCount: data.ratingCount,
        bestRating: '5',
        worstRating: '1'
      }
    } : {}),
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
      availability: 'https://schema.org/InStock'
    },
    publisher: STRUCTURED_DATA.organization
  };
}