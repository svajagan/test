import { event } from '../analytics';

export function trackTiming(
  category: string,
  variable: string,
  value: number,
  label?: string
) {
  event({
    action: variable,
    category: category,
    label: label,
    value: value
  });
}