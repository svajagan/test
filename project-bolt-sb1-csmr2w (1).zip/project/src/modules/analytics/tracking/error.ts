import { event } from '../analytics';

export function trackError(error: Error, fatal: boolean = false) {
  event({
    action: 'error_occurred',
    category: 'Error',
    label: error.message,
    value: fatal ? 1 : 0
  });
}