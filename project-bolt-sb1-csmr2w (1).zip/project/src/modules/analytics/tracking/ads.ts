import { trackEvent } from '../core/events';

export type AdAction = 'init' | 'request' | 'complete' | 'incomplete' | 'error' | 'init_error';

export const trackAdInteraction = (adType: string, action: AdAction) => {
  trackEvent({
    action: 'ad_interaction',
    category: 'Ads',
    label: `${adType}_${action}`,
    value: action === 'error' || action === 'init_error' ? 0 : 1
  });
};