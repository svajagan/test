import { pageview } from '../analytics';

export function trackPageView(path: string) {
  pageview(path);

  if (window.clarity) {
    window.clarity('pageview', path);
  }
}