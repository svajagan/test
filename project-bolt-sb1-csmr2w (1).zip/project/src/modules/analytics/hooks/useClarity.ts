import { useCallback } from 'react';

export function useClarity() {
  const trackEvent = useCallback((event: string, properties?: Record<string, any>): void => {
    if (window.clarity) {
      window.clarity('event', event, properties);
    }
  }, []);

  const setCustomData = useCallback((key: string, value: string): void => {
    if (window.clarity) {
      window.clarity('set', key, value);
    }
  }, []);

  const identify = useCallback((userId: string): void => {
    if (window.clarity) {
      window.clarity('identify', userId);
    }
  }, []);

  return {
    trackEvent,
    setCustomData,
    identify
  };
}