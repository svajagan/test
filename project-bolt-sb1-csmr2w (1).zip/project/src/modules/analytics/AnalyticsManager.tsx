import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { pageview, event } from './analytics';
import type { GameState } from '../game/types';
import type { AnalyticsEvent } from './types';

// Analytics React Component
export function Analytics() {
  const location = useLocation();

  useEffect(() => {
    trackPageView(location.pathname);
  }, [location]);

  return null;
}

// Analytics tracking functions
export function trackPageView(path: string) {
  pageview(path);

  if (window.clarity) {
    window.clarity('pageview', path);
  }
}

export function trackGameStart() {
  event({
    action: 'game_start',
    category: 'Game'
  });
}

export function trackGameOver(state: GameState) {
  event({
    action: 'game_over',
    category: 'Game',
    label: 'Game Over',
    value: state.score
  });
}

export function trackLevelComplete(level: number, score: number) {
  event({
    action: 'level_complete',
    category: 'Game',
    label: `Level ${level}`,
    value: score
  });
}

export function trackAdInteraction(
  adType: string,
  action: 'init' | 'request' | 'complete' | 'incomplete' | 'error' | 'init_error'
) {
  event({
    action: 'ad_interaction',
    category: 'Ads',
    label: `${adType}_${action}`,
    value: action === 'error' || action === 'init_error' ? 0 : 1
  });
}

// Error tracking
export function trackError(error: Error, fatal: boolean = false) {
  event({
    action: 'error_occurred',
    category: 'Error',
    label: error.message,
    value: fatal ? 1 : 0
  });
}

// Performance tracking
export function trackTiming(
  category: string,
  variable: string,
  value: number,
  label?: string
) {
  event({
    action: variable,
    category: category,
    label: label,
    value: value
  });
}