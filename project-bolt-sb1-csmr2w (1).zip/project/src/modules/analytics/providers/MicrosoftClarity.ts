export const initializeMicrosoftClarity = () => {
  if (process.env.NODE_ENV === 'production') {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.crossOrigin = 'anonymous';
    script.src = 'https://www.clarity.ms/tag/p4ny0e4ww8';
    
    // Initialize clarity function before loading script
    window.clarity = window.clarity || function(...args) {
      (window.clarity.q = window.clarity.q || []).push(args);
    };
    
    document.head.appendChild(script);
  }
};

export const trackClarityEvent = (event: string, properties?: Record<string, any>) => {
  if (window.clarity) {
    try {
      window.clarity('event', event, properties);
    } catch (error) {
      console.debug('Clarity tracking error:', error);
    }
  }
};