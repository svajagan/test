import { AnalyticsEvent } from '../types';

export const initializeGoogleAnalytics = () => {
  if (typeof window !== 'undefined') {
    window.dataLayer = window.dataLayer || [];
    window.gtag = function() {
      window.dataLayer.push(arguments);
    }
    window.gtag('js', new Date());
    window.gtag('config', 'G-K99WE65NDE');
  }
};

export const trackGoogleEvent = (event: AnalyticsEvent) => {
  if (typeof window.gtag === 'function') {
    try {
      window.gtag('event', event.action, {
        event_category: event.category,
        event_label: event.label,
        value: event.value
      });
    } catch (error) {
      console.debug('Google Analytics tracking error:', error);
    }
  }
};