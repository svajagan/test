import React, { useEffect } from 'react';
import ReactGA from 'react-ga4';
import { trackPageView, trackError } from './AnalyticsManager';

type GAProviderProps = {
  children: React.ReactNode;
};

export function GAProvider({ children }: GAProviderProps) {
  useEffect(() => {
    // Track initial page view
    trackPageView(window.location.pathname + window.location.search);

    // Set up error boundary tracking
    const originalOnError = window.onerror;
    window.onerror = (message, source, lineno, colno, error) => {
      trackError(error || new Error(String(message)), true);
      if (originalOnError) {
        return originalOnError(message, source, lineno, colno, error);
      }
      return false;
    };

    // Track unhandled promise rejections
    const originalOnUnhandledRejection = window.onunhandledrejection;
    window.onunhandledrejection = (event) => {
      trackError(event.reason, true);
      if (originalOnUnhandledRejection) {
        return originalOnUnhandledRejection(event);
      }
    };

    // Clean up error handlers
    return () => {
      window.onerror = originalOnError;
      window.onunhandledrejection = originalOnUnhandledRejection;
    };
  }, []);

  return <>{children}</>;
}

// Custom hook for tracking events
export function useAnalytics() {
  const trackEvent = (
    category: string,
    action: string,
    label?: string,
    value?: number,
    nonInteraction: boolean = false
  ) => {
    ReactGA.event({
      category,
      action,
      label,
      value,
      nonInteraction
    });
  };

  const trackCustomEvent = (
    name: string,
    params: { [key: string]: any } = {}
  ) => {
    ReactGA.event(name, params);
  };

  const trackSocialInteraction = (
    network: string,
    action: string,
    target: string
  ) => {
    ReactGA.event({
      category: 'Social',
      action: action,
      label: network,
      dimension1: target
    });
  };

  const trackException = (description: string, fatal: boolean = false) => {
    ReactGA.event({
      category: 'Error',
      action: 'exception',
      label: description,
      nonInteraction: true,
      fatal
    });
  };

  return {
    trackEvent,
    trackCustomEvent,
    trackSocialInteraction,
    trackException
  };
}