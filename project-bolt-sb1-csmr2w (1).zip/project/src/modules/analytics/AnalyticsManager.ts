import { initializeGoogleAnalytics } from './providers/GoogleAnalytics';
import { initializeMicrosoftClarity } from './providers/MicrosoftClarity';

let initialized = false;

export * from './tracking/game';
export * from './tracking/ads';
export * from './core/events';

const initializeAnalytics = async () => {
  if (initialized) return;
  
  try {
    initializeGoogleAnalytics();
    initializeMicrosoftClarity();
    initialized = true;
  } catch (error) {
    console.debug('Analytics initialization error:', error);
  }
};

// Initialize analytics when module loads
if (typeof window !== 'undefined') {
  void initializeAnalytics();
}