import type { AnalyticsEvent } from '../types';
import { trackGoogleEvent } from '../providers/GoogleAnalytics';
import { trackClarityEvent } from '../providers/MicrosoftClarity';

export const trackEvent = (event: AnalyticsEvent) => {
  try {
    // Track in Google Analytics
    trackGoogleEvent(event);
  
    // Track in Microsoft Clarity
    trackClarityEvent(event.action, {
      category: event.category,
      label: event.label,
      value: event.value
    });
  } catch (error) {
    console.debug('Event tracking error:', error);
  }
};