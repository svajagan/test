import { GameState, GameSet, Category, Difficulty } from '../../game/types';
import { calculateTimeLimit } from './scoring';
import { getRandomCategory, getRandomSet } from '../utils/generators';
import { checkAchievements } from './achievements';
import { updateHighScores } from './highscores';
import { checkDifficultyProgression } from './progression';

export const INITIAL_STATE: GameState = {
  score: 0,
  currentLevel: 1,
  lives: 3,
  gameOver: false,
  gameStarted: false,
  hintsRemaining: 3,
  currentStreak: 0,
  bestStreak: 0,
  timeRemaining: 30,
  showHint: false,
  lastResult: null,
  difficulty: Difficulty.Easy,
  totalGamesPlayed: 0,
  highScores: [],
  timeBonus: 0,
  streakBonus: 0,
  difficultyBonus: 0,
  achievements: [],
};

export const calculateBonuses = (state: GameState) => {
  const timeBonus = Math.ceil(state.timeRemaining * 10);
  const streakBonus = state.currentStreak * 50;
  const difficultyBonus = (() => {
    switch (state.difficulty) {
      case Difficulty.Expert: return 200;
      case Difficulty.Hard: return 150;
      case Difficulty.Medium: return 100;
      default: return 50;
    }
  })();

  return { timeBonus, streakBonus, difficultyBonus };
};

export const getNextGameState = (state: GameState, isCorrect: boolean, guess?: string) => {
  if (isCorrect) {
    const category = getRandomCategory(state.difficulty);
    const gameSet = getRandomSet(category);
    const bonuses = calculateBonuses(state);
    const newScore = state.score + bonuses.timeBonus + bonuses.streakBonus + bonuses.difficultyBonus;
    const newLevel = state.currentLevel + 1;
    const newDifficulty = checkDifficultyProgression({ ...state, score: newScore });
    const newAchievements = [
      ...state.achievements,
      ...checkAchievements({ ...state, currentLevel: newLevel })
    ];

    return {
      ...state,
      score: newScore,
      currentLevel: newLevel,
      currentStreak: state.currentStreak + 1,
      bestStreak: Math.max(state.currentStreak + 1, state.bestStreak),
      timeRemaining: calculateTimeLimit(newLevel, state.difficulty),
      timeBonus: bonuses.timeBonus,
      streakBonus: bonuses.streakBonus,
      difficultyBonus: bonuses.difficultyBonus,
      currentCategory: category,
      currentSet: gameSet,
      showHint: false,
      difficulty: newDifficulty,
      achievements: newAchievements,
      lastResult: {
        correct: true,
        bonus: streakBonus + difficultyBonus,
        message: `Perfect! +${timeBonus} time bonus, +${streakBonus} streak bonus, +${difficultyBonus} difficulty bonus`
      }
    };
  } else {
    const newLives = state.lives - 1;
    const isGameOver = newLives === 0;

    if (isGameOver) {
      const newHighScores = updateHighScores(state);

      return {
        ...state,
        lives: newLives,
        gameOver: true,
        currentStreak: 0,
        showHint: false,
        totalGamesPlayed: state.totalGamesPlayed + 1,
        highScores: newHighScores,
        lastResult: {
          correct: false,
          mistake: guess,
          message: 'Game Over! Your score has been recorded.'
        }
      };
    }

    return {
      ...state,
      lives: newLives,
      currentStreak: 0,
      showHint: false,
      lastResult: {
        correct: false,
        mistake: guess,
        message: `Wrong! ${newLives} ${newLives === 1 ? 'life' : 'lives'} remaining`
      }
    };
  }
};