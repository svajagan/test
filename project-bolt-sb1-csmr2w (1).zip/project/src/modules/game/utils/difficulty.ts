import { Category, Difficulty } from '../types';
import { difficultyProgression } from '../../../data/categories';

export const getDifficultyMultiplier = (category: Category): number => {
  return difficultyProgression.bonusMultipliers[category.difficulty];
};

export const getTimeLimit = (difficulty: Difficulty, baseTime: number): number => {
  return Math.ceil(baseTime * difficultyProgression.timeMultipliers[difficulty]);
};

export const getCurrentDifficulty = (score: number): Difficulty => {
  const thresholds = difficultyProgression.scoreThresholds;
  
  if (score >= thresholds[Difficulty.Expert]) return Difficulty.Expert;
  if (score >= thresholds[Difficulty.Hard]) return Difficulty.Hard;
  if (score >= thresholds[Difficulty.Medium]) return Difficulty.Medium;
  return Difficulty.Easy;
};

export const getDifficultyColor = (difficulty: Difficulty): string => {
  switch (difficulty) {
    case Difficulty.Expert:
      return 'text-red-500 dark:text-red-400';
    case Difficulty.Hard:
      return 'text-orange-500 dark:text-orange-400';
    case Difficulty.Medium:
      return 'text-yellow-500 dark:text-yellow-400';
    default:
      return 'text-green-500 dark:text-green-400';
  }
};

export const getDifficultyBadgeColor = (difficulty: Difficulty): string => {
  switch (difficulty) {
    case Difficulty.Expert:
      return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    case Difficulty.Hard:
      return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
    case Difficulty.Medium:
      return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    default:
      return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
  }
};