import { GameState, HighScore } from '../types';

export const updateHighScores = (state: GameState): HighScore[] => {
  const newScore: HighScore = {
    score: state.score,
    date: new Date().toISOString(),
    difficulty: state.difficulty,
    level: state.currentLevel,
    achievements: state.achievements
  };

  return [...state.highScores, newScore]
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
};