import { describe, it, expect } from 'vitest';
import { calculateScore, calculateTimeLimit, calculateStreak, getStreakBonus } from '../scoring';
import { Difficulty } from '../../types';

describe('scoring utils', () => {
  describe('calculateScore', () => {
    it('should calculate correct base score', () => {
      expect(calculateScore(30, Difficulty.Easy, 0)).toBe(300);
      expect(calculateScore(15, Difficulty.Easy, 0)).toBe(150);
    });

    it('should apply difficulty multipliers correctly', () => {
      const timeRemaining = 20;
      const streak = 0;
      expect(calculateScore(timeRemaining, Difficulty.Easy, streak)).toBe(200);
      expect(calculateScore(timeRemaining, Difficulty.Medium, streak)).toBe(300);
      expect(calculateScore(timeRemaining, Difficulty.Hard, streak)).toBe(400);
      expect(calculateScore(timeRemaining, Difficulty.Expert, streak)).toBe(600);
    });

    it('should include streak bonus', () => {
      const timeRemaining = 20;
      const streak = 2;
      const baseScore = calculateScore(timeRemaining, Difficulty.Easy, 0);
      const withStreakScore = calculateScore(timeRemaining, Difficulty.Easy, streak);
      expect(withStreakScore).toBe(baseScore + (streak * 50));
    });
  });

  describe('calculateTimeLimit', () => {
    it('should calculate correct base time limit', () => {
      expect(calculateTimeLimit(1, Difficulty.Easy)).toBe(30);
      expect(calculateTimeLimit(5, Difficulty.Easy)).toBe(29);
    });

    it('should apply difficulty multipliers to time limit', () => {
      const level = 1;
      expect(calculateTimeLimit(level, Difficulty.Easy)).toBe(30);
      expect(calculateTimeLimit(level, Difficulty.Medium)).toBe(24);
      expect(calculateTimeLimit(level, Difficulty.Hard)).toBe(18);
      expect(calculateTimeLimit(level, Difficulty.Expert)).toBe(12);
    });

    it('should not go below minimum time limit', () => {
      const highLevel = 100;
      expect(calculateTimeLimit(highLevel, Difficulty.Easy)).toBeGreaterThanOrEqual(15);
    });
  });

  describe('calculateStreak', () => {
    it('should increment streak on correct answer', () => {
      expect(calculateStreak(0, true)).toBe(1);
      expect(calculateStreak(1, true)).toBe(2);
      expect(calculateStreak(5, true)).toBe(6);
    });

    it('should reset streak on wrong answer', () => {
      expect(calculateStreak(1, false)).toBe(0);
      expect(calculateStreak(5, false)).toBe(0);
      expect(calculateStreak(10, false)).toBe(0);
    });
  });

  describe('getStreakBonus', () => {
    it('should return correct bonus based on streak', () => {
      expect(getStreakBonus(0)).toBe(0);
      expect(getStreakBonus(2)).toBe(0);
      expect(getStreakBonus(3)).toBe(50);
      expect(getStreakBonus(4)).toBe(50);
      expect(getStreakBonus(5)).toBe(100);
      expect(getStreakBonus(9)).toBe(100);
      expect(getStreakBonus(10)).toBe(200);
      expect(getStreakBonus(15)).toBe(200);
    });
  });
});