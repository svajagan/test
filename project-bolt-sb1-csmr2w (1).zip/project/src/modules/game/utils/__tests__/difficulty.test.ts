import { describe, it, expect } from 'vitest';
import { 
  getDifficultyMultiplier, 
  getTimeLimit, 
  getCurrentDifficulty,
  getDifficultyColor,
  getDifficultyBadgeColor
} from '../difficulty';
import { Difficulty } from '../../types';

describe('difficulty utils', () => {
  describe('getDifficultyMultiplier', () => {
    it('should return correct multiplier for each difficulty', () => {
      const testCases = [
        { difficulty: Difficulty.Easy, expected: 1 },
        { difficulty: Difficulty.Medium, expected: 1.5 },
        { difficulty: Difficulty.Hard, expected: 2 },
        { difficulty: Difficulty.Expert, expected: 3 },
      ];

      testCases.forEach(({ difficulty, expected }) => {
        const category = { name: 'Test', difficulty, sets: [] };
        expect(getDifficultyMultiplier(category)).toBe(expected);
      });
    });
  });

  describe('getTimeLimit', () => {
    it('should apply correct time multipliers', () => {
      const baseTime = 30;
      expect(getTimeLimit(Difficulty.Easy, baseTime)).toBe(30);
      expect(getTimeLimit(Difficulty.Medium, baseTime)).toBe(24);
      expect(getTimeLimit(Difficulty.Hard, baseTime)).toBe(18);
      expect(getTimeLimit(Difficulty.Expert, baseTime)).toBe(12);
    });

    it('should round up decimal results', () => {
      const baseTime = 25;
      expect(getTimeLimit(Difficulty.Medium, baseTime)).toBe(20);
    });
  });

  describe('getCurrentDifficulty', () => {
    it('should return correct difficulty based on score', () => {
      expect(getCurrentDifficulty(0)).toBe(Difficulty.Easy);
      expect(getCurrentDifficulty(500)).toBe(Difficulty.Easy);
      expect(getCurrentDifficulty(1000)).toBe(Difficulty.Medium);
      expect(getCurrentDifficulty(2500)).toBe(Difficulty.Hard);
      expect(getCurrentDifficulty(5000)).toBe(Difficulty.Expert);
      expect(getCurrentDifficulty(10000)).toBe(Difficulty.Expert);
    });
  });

  describe('getDifficultyColor', () => {
    it('should return correct color classes for each difficulty', () => {
      expect(getDifficultyColor(Difficulty.Easy)).toContain('text-green');
      expect(getDifficultyColor(Difficulty.Medium)).toContain('text-yellow');
      expect(getDifficultyColor(Difficulty.Hard)).toContain('text-orange');
      expect(getDifficultyColor(Difficulty.Expert)).toContain('text-red');
    });

    it('should include dark mode variants', () => {
      Object.values(Difficulty).forEach(difficulty => {
        const colorClass = getDifficultyColor(difficulty);
        expect(colorClass).toContain('dark:');
      });
    });
  });

  describe('getDifficultyBadgeColor', () => {
    it('should return correct background and text colors', () => {
      Object.values(Difficulty).forEach(difficulty => {
        const colorClass = getDifficultyBadgeColor(difficulty);
        expect(colorClass).toContain('bg-');
        expect(colorClass).toContain('text-');
      });
    });

    it('should include dark mode variants', () => {
      Object.values(Difficulty).forEach(difficulty => {
        const colorClass = getDifficultyBadgeColor(difficulty);
        expect(colorClass).toContain('dark:bg-');
        expect(colorClass).toContain('dark:text-');
      });
    });
  });
});