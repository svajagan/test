import { categories } from '../../../data/categories/index';
import { Category, GameSet, Difficulty } from '../../game/types';

export const getRandomSet = (category: Category | undefined): GameSet | undefined => {
  if (!category?.sets?.length) return undefined;
  const availableSets = category.sets;
  return availableSets[Math.floor(Math.random() * availableSets.length)];
};

export const getRandomCategory = (difficulty?: Difficulty): Category => {
  const availableCategories = difficulty 
    ? categories.filter(c => c.difficulty === difficulty)
    : categories;
  
  if (!availableCategories.length) {
    return categories[0]; // Fallback to first category if none match difficulty
  }
  
  return availableCategories[Math.floor(Math.random() * availableCategories.length)];
};