import { Difficulty } from '../../../types/game';
import { difficultyProgression } from '../../../data/categories';

export const calculateTimeBonus = (timeRemaining: number): number => {
  return Math.max(0, Math.ceil(timeRemaining * 10));
};

export const calculateStreakBonus = (streak: number): number => {
  return streak * 50;
};

export const calculateDifficultyBonus = (difficulty: Difficulty): number => {
  return Math.ceil(100 * difficultyProgression.bonusMultipliers[difficulty]);
};

export const calculateTotalScore = (
  timeRemaining: number,
  streak: number,
  difficulty: Difficulty
): number => {
  const timeBonus = calculateTimeBonus(timeRemaining);
  const streakBonus = calculateStreakBonus(streak);
  const difficultyBonus = calculateDifficultyBonus(difficulty);
  
  return timeBonus + streakBonus + difficultyBonus;
};

export const calculateTimeLimit = (level: number, difficulty: Difficulty): number => {
  const baseTime = Math.max(30 - Math.floor((level - 1) / 5), 15);
  return Math.ceil(baseTime * difficultyProgression.timeMultipliers[difficulty]);
};