import { describe, it, expect } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useGameLogic } from '../useGameLogic';
import { GameSet, Category, Difficulty } from '../../types';

describe('useGameLogic', () => {
  const mockCategory: Category = {
    name: 'Animals',
    difficulty: Difficulty.Easy,
    sets: []
  };

  const mockGameSet: GameSet = {
    items: ['Lion', 'Tiger', 'Penguin', 'Cheetah'],
    oddOneOut: 'Penguin',
    explanation: 'Penguin is a bird, others are cats',
    hint: 'Think about animal families',
  };

  it('should evaluate correct guess correctly', () => {
    const { result } = renderHook(() => useGameLogic());
    const gameResult = result.current.evaluateGuess(mockGameSet, mockCategory, 'Penguin', 30, 2);

    expect(gameResult.correct).toBe(true);
    expect(gameResult.bonus).toBeGreaterThan(0);
  });

  it('should evaluate incorrect guess correctly', () => {
    const { result } = renderHook(() => useGameLogic());
    const gameResult = result.current.evaluateGuess(mockGameSet, mockCategory, 'Lion', 30, 2);

    expect(gameResult.correct).toBe(false);
    expect(gameResult.mistake).toBe('Lion');
  });
});