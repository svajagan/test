import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useGamePerformance } from '../useGamePerformance';

describe('useGamePerformance', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.spyOn(performance, 'now')
      .mockImplementationOnce(() => 0)
      .mockImplementationOnce(() => 16.67)
      .mockImplementationOnce(() => 33.34);
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('should initialize with empty metrics', () => {
    const { result } = renderHook(() => useGamePerformance());
    expect(result.current.getPerformanceMetrics()).toBe(null);
  });

  it('should calculate FPS correctly', () => {
    const { result } = renderHook(() => useGamePerformance());
    
    // Simulate 60fps
    for (let i = 0; i < 60; i++) {
      vi.advanceTimersByTime(16.67); // ~60fps
    }
    
    const metrics = result.current.getPerformanceMetrics();
    expect(metrics?.fps).toBeCloseTo(60, 0);
  });

  it('should track frame time variations', () => {
    const { result } = renderHook(() => useGamePerformance());
    
    // Simulate varying frame times
    const frameTimes = [16.67, 33.34, 16.67]; // Mix of 60fps and 30fps
    frameTimes.forEach(time => {
      vi.advanceTimersByTime(time);
    });
    
    const metrics = result.current.getPerformanceMetrics();
    expect(metrics?.minFps).toBeLessThan(metrics?.maxFps as number);
  });

  it('should maintain performance under load', () => {
    const { result } = renderHook(() => useGamePerformance());
    
    // Simulate heavy load
    for (let i = 0; i < 1000; i++) {
      vi.advanceTimersByTime(16.67);
    }
    
    const metrics = result.current.getPerformanceMetrics();
    expect(metrics?.avgFrameTime).toBeLessThan(20); // Less than 20ms per frame
  });

  it('should cleanup animation frame on unmount', () => {
    const cancelAnimationFrame = vi.spyOn(window, 'cancelAnimationFrame');
    const { unmount } = renderHook(() => useGamePerformance());
    
    unmount();
    expect(cancelAnimationFrame).toHaveBeenCalled();
  });
});