import React from 'react';
import { Helmet } from 'react-helmet';
import { Card } from '../modules/ui/components/Card';
import { Brain, Users, Award, Code } from 'lucide-react';

export default function AboutPage() {
  return (
    <>
      <Helmet>
        <title>About 1 Odd Out | Science-Based Brain Training Games</title>
        <meta name="description" content="Learn about our science-based approach to brain training. Discover how 1 Odd Out helps millions improve cognitive skills through engaging puzzles." />
      </Helmet>

      <div className="max-w-4xl mx-auto p-4 space-y-8">
        <h1 className="text-4xl font-bold text-center mb-8">About 1 Odd Out</h1>
        
        <Card className="space-y-6">
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Brain className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">Our Mission</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              1 Odd Out was created with a simple mission: to make brain training fun, accessible, and scientifically sound. 
              We believe that cognitive exercise should be as engaging as it is effective.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">Our Community</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              Join over 1 million players worldwide who use 1 Odd Out to challenge their minds daily. 
              Our diverse community spans across all age groups and skill levels.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Award className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">Scientific Approach</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              Every puzzle in 1 Odd Out is carefully designed based on cognitive science principles. 
              We work with neuroscientists to ensure our games provide meaningful mental exercise.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Code className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">Technology</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              Built using cutting-edge web technologies, 1 Odd Out provides a seamless gaming experience 
              across all devices. Our progressive web app works offline and updates automatically.
            </p>
          </section>
        </Card>
      </div>
    </>
  );
}