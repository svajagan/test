import React from 'react';
import { Helmet } from 'react-helmet';
import { BlogList } from '../../components/BlogList';

export default function BlogIndexRoute() {
  return (
    <>
      <Helmet>
        <title>Brain Training Tips & Research | Cognitive Science Blog</title>
        <meta name="description" content="Explore the science of brain training! Read expert articles on cognitive improvement, memory enhancement, and the latest neuroscience research." />
        <meta name="keywords" content="brain training blog, cognitive science articles, memory improvement tips, neuroscience research, mental exercise guides" />
        <link rel="canonical" href="https://1oddout.com/blog" />
      </Helmet>

      <BlogList />
    </>
  );
}