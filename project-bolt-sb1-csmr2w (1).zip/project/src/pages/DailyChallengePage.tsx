import React from 'react';
import { Helmet } from 'react-helmet';
import { Card } from '../modules/ui/components/Card';
import { Calendar, Trophy, Timer } from 'lucide-react';
import { Button } from '../modules/ui/components/Button';
import { Badge } from '../modules/ui/components/Badge';

export default function DailyChallengePage() {
  return (
    <>
      <Helmet>
        <title>Daily Brain Training Challenge | 1 Odd Out</title>
        <meta name="description" content="Take on our daily brain training challenge! New puzzles every day to test your cognitive skills. Compare scores with players worldwide." />
      </Helmet>

      <div className="max-w-4xl mx-auto p-4 space-y-8">
        <h1 className="text-4xl font-bold text-center mb-8">Daily Challenge</h1>

        <Card className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-lg font-semibold">Today's Challenge</h2>
            </div>
            <Badge variant="blue">New</Badge>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Timer className="w-4 h-4 text-system-gray-1" />
                <span>Resets in: 12:34:56</span>
              </div>
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-system-yellow dark:text-system-yellow-dark" />
                <span>Best: 2,500</span>
              </div>
            </div>

            <Button className="w-full">Start Today's Challenge</Button>
          </div>
        </Card>

        <Card>
          <h2 className="text-xl font-semibold mb-4">Previous Results</h2>
          <div className="space-y-3">
            {[
              { date: 'March 17', score: 2500, rank: 42 },
              { date: 'March 16', score: 2200, rank: 67 },
              { date: 'March 15', score: 2800, rank: 23 },
            ].map((result) => (
              <div key={result.date} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-xl">
                <span className="text-gray-600 dark:text-gray-400">{result.date}</span>
                <div className="flex items-center gap-4">
                  <span className="font-medium">{result.score.toLocaleString()} pts</span>
                  <Badge variant="purple">#{result.rank}</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}