import React from 'react';
import { Helmet } from 'react-helmet';
import { WelcomeScreen } from '../components/WelcomeScreen';
import { GameBoard } from '../components/GameBoard';
import { generateMetaTags } from '../modules/seo/utils/metadata';
import { generateGameSchema } from '../modules/seo/utils/schema';
import { useGameStore } from '../store/gameStore';

export default function HomePage() {
  const { state, actions } = useGameStore();

  const pageTitle = '1 Odd Out - Best Free Brain Training Game 2024';
  const pageDescription = '🧠 Boost your cognitive skills with 1 Odd Out, the #1 brain training puzzle game of 2024. Test logical thinking, pattern recognition, and mental agility. Join 1M+ players worldwide!';

  return (
    <>
      <Helmet>
        <title>{pageTitle}</title>
        {generateMetaTags({
          title: pageTitle,
          description: pageDescription,
          type: 'website',
          url: 'https://www.1oddout.com'
        }).map((tag) => (
          <meta key={tag.name || tag.property} {...tag} />
        ))}
        <meta name="keywords" content="brain training game, puzzle game 2024, cognitive skills training, mental exercise games, logic puzzles online, pattern recognition games, educational brain games, mind training games, brain teasers" />
        <link rel="canonical" href="https://1oddout.com" />
        <meta property="article:modified_time" content={new Date().toISOString()} />
        <script type="application/ld+json">
          {JSON.stringify(generateGameSchema({
            name: '1 Odd Out',
            description: pageDescription,
            rating: 4.8,
            ratingCount: 15243
          }))}
        </script>
      </Helmet>

      <main className="min-h-screen">
        {!state.gameStarted ? (
          <WelcomeScreen onStart={actions.startGame} />
        ) : (
          <GameBoard />
        )}
      </main>
    </>
  );
}