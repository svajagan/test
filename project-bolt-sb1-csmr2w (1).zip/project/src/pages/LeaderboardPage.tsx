import React from 'react';
import { Helmet } from 'react-helmet';
import { Card } from '../modules/ui/components/Card';
import { Trophy, Medal, Crown, Users } from 'lucide-react';
import { Badge } from '../modules/ui/components/Badge';

export default function LeaderboardPage() {
  return (
    <>
      <Helmet>
        <title>Global Leaderboard | 1 Odd Out Brain Training</title>
        <meta name="description" content="See how your brain training scores compare globally! View top players, achievements, and compete in our worldwide cognitive skills leaderboard." />
      </Helmet>

      <div className="max-w-4xl mx-auto p-4 space-y-8">
        <h1 className="text-4xl font-bold text-center mb-8">Global Leaderboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="text-center">
            <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <h2 className="text-lg font-semibold mb-1">All Time Best</h2>
            <p className="text-2xl font-bold text-system-blue dark:text-system-blue-dark">12,500</p>
          </Card>

          <Card className="text-center">
            <Users className="w-8 h-8 text-system-blue dark:text-system-blue-dark mx-auto mb-2" />
            <h2 className="text-lg font-semibold mb-1">Active Players</h2>
            <p className="text-2xl font-bold text-system-blue dark:text-system-blue-dark">1.2M</p>
          </Card>

          <Card className="text-center">
            <Crown className="w-8 h-8 text-purple-500 mx-auto mb-2" />
            <h2 className="text-lg font-semibold mb-1">Your Rank</h2>
            <p className="text-2xl font-bold text-system-blue dark:text-system-blue-dark">#42</p>
          </Card>
        </div>

        <Card>
          <h2 className="text-xl font-semibold mb-6">Top Players</h2>
          <div className="space-y-4">
            {[
              { rank: 1, name: 'BrainMaster', score: 12500, country: '🇺🇸' },
              { rank: 2, name: 'LogicPro', score: 12100, country: '🇬🇧' },
              { rank: 3, name: 'MindGuru', score: 11800, country: '🇯🇵' },
              { rank: 4, name: 'PuzzleKing', score: 11500, country: '🇩🇪' },
              { rank: 5, name: 'BrainWave', score: 11200, country: '🇫🇷' },
            ].map((player) => (
              <div key={player.rank} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                <div className="flex items-center gap-4">
                  {player.rank === 1 ? (
                    <Medal className="w-6 h-6 text-yellow-500" />
                  ) : player.rank === 2 ? (
                    <Medal className="w-6 h-6 text-gray-400" />
                  ) : player.rank === 3 ? (
                    <Medal className="w-6 h-6 text-amber-600" />
                  ) : (
                    <span className="w-6 text-center font-medium">{player.rank}</span>
                  )}
                  <span className="font-medium">{player.country} {player.name}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold">{player.score.toLocaleString()}</span>
                  <Badge variant="blue">Elite</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}