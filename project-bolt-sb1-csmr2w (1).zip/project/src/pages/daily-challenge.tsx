import React from 'react';
import { Helmet } from 'react-helmet';
import { DailyChallenge } from '../components/DailyChallenge';

export default function DailyChallengeRoute() {
  return (
    <>
      <Helmet>
        <title>Daily Brain Training Challenge | 1 Odd Out - Free Puzzle Game</title>
        <meta name="description" content="Take on our daily brain training challenge! New puzzles every day to test your cognitive skills. Compare scores with players worldwide and track your progress." />
        <meta name="keywords" content="daily brain training, daily puzzle game, daily brain teasers, cognitive challenge, mind games daily, brain exercise" />
        <link rel="canonical" href="https://1oddout.com/daily-challenge" />
      </Helmet>

      <DailyChallenge />
    </>
  );
}