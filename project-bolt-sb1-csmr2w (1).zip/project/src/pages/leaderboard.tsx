import React from 'react';
import { Helmet } from 'react-helmet';
import { Leaderboard } from '../components/Leaderboard';

export default function LeaderboardRoute() {
  return (
    <>
      <Helmet>
        <title>Global Brain Training Leaderboard | Compare Your Cognitive Skills</title>
        <meta name="description" content="See how your brain training scores compare globally! View top players, achievements, and compete in our worldwide cognitive skills leaderboard." />
        <meta name="keywords" content="brain training leaderboard, cognitive skills ranking, puzzle game scores, global mind game competition, brain training achievements" />
        <link rel="canonical" href="https://1oddout.com/leaderboard" />
      </Helmet>

      <Leaderboard />
    </>
  );
}