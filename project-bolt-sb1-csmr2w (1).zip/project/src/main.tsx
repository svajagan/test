import "@fontsource-variable/inter/standard.css";
import './index.css';
import { lazy, StrictMode, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { registerSW } from 'virtual:pwa-register';
import App from './App';
import { Analytics } from './modules/analytics';

const updateSW = registerSW({
  onNeedRefresh() {},
  onOfflineReady() {},
  immediate: true
});

document.addEventListener('touchstart', () => {}, { passive: true });
document.addEventListener('wheel', () => {}, { passive: true });

const initApp = () => {
  const root = document.getElementById('root');
  if (!root) throw new Error('Root element not found');

  createRoot(root).render(
    <StrictMode>
      <BrowserRouter>
        <Analytics />
        <App />
      </BrowserRouter>
    </StrictMode>
  );
};

initApp();