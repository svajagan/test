import React from 'react';
import { motion } from 'framer-motion';
import { Users } from 'lucide-react';
import { Badge } from '../modules/ui/components/Badge';

type VisitorCounterProps = {
  count: number;
};

export function VisitorCounter({ count }: VisitorCounterProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-4 left-4 z-50"
    >
      <Badge variant="purple" className="flex items-center gap-2">
        <Users className="w-4 h-4" />
        <span>{count.toLocaleString()} playing</span>
      </Badge>
    </motion.div>
  );
}