import React from 'react';
import { motion } from 'framer-motion';
import { Difficulty } from '../types/game';
import { getDifficultyBadgeColor } from '../modules/game/utils/difficulty';

type DifficultyBadgeProps = {
  difficulty: Difficulty;
  animate?: boolean;
  className?: string;
};

export function DifficultyBadge({ 
  difficulty, 
  animate = true,
  className = ''
}: DifficultyBadgeProps) {
  const Component = animate ? motion.div : 'div';
  const colorClass = getDifficultyBadgeColor(difficulty);

  return (
    <Component
      initial={animate ? { scale: 0.9, opacity: 0 } : undefined}
      animate={animate ? { scale: 1, opacity: 1 } : undefined}
      className={`
        inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
        ${colorClass}
        ${className}
      `}
    >
      {difficulty}
    </Component>
  );
}