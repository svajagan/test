import React from 'react';
import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="w-full py-6 px-4 mt-auto">
      <nav className="max-w-4xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4" aria-label="Footer Navigation">
        <div className="text-sm text-gray-600 dark:text-gray-400">
          © 2024 1 Odd Out. All rights reserved.
        </div>
        <ul className="flex items-center gap-6">
          <li>
            <Link to="/how-to-play" className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors">
              How to Play
            </Link>
          </li>
          <li>
          <Link 
            to="/privacy" 
            className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors"
          >
            Privacy Policy
          </Link>
          </li>
          <li>
          <Link 
            to="/terms" 
            className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors"
          >
            Terms of Service
          </Link>
          </li>
        </ul>
      </nav>
    </footer>
  );
}