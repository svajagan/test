import React from 'react';
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { DifficultyBadge } from '../DifficultyBadge';
import { Difficulty } from '../../types/game';

describe('DifficultyBadge', () => {
  it('renders difficulty text correctly', () => {
    render(<DifficultyBadge difficulty={Difficulty.Easy} />);
    expect(screen.getByText('EASY')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    render(<DifficultyBadge difficulty={Difficulty.Medium} className="custom-class" />);
    const badge = screen.getByText('MEDIUM');
    expect(badge.parentElement).toHaveClass('custom-class');
  });

  it('renders without animation when animate is false', () => {
    render(<DifficultyBadge difficulty={Difficulty.Hard} animate={false} />);
    const badge = screen.getByText('HARD');
    expect(badge.parentElement?.tagName.toLowerCase()).toBe('div');
  });

  it('applies correct color classes for each difficulty', () => {
    const { rerender } = render(<DifficultyBadge difficulty={Difficulty.Easy} />);
    expect(screen.getByText('EASY').parentElement).toHaveClass('bg-green-100');

    rerender(<DifficultyBadge difficulty={Difficulty.Medium} />);
    expect(screen.getByText('MEDIUM').parentElement).toHaveClass('bg-yellow-100');

    rerender(<DifficultyBadge difficulty={Difficulty.Hard} />);
    expect(screen.getByText('HARD').parentElement).toHaveClass('bg-orange-100');

    rerender(<DifficultyBadge difficulty={Difficulty.Expert} />);
    expect(screen.getByText('EXPERT').parentElement).toHaveClass('bg-red-100');
  });
});