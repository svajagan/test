import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ShareButton } from '../ShareButton';

describe('ShareButton', () => {
  const defaultProps = {
    score: 1000,
    url: 'https://example.com/game'
  };

  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders share button with correct text', () => {
    render(<ShareButton {...defaultProps} />);
    expect(screen.getByText('Share Score')).toBeInTheDocument();
  });

  it('renders social media share buttons', () => {
    render(<ShareButton {...defaultProps} />);
    expect(screen.getByRole('button', { name: /whatsapp/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /twitter/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /telegram/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /facebook/i })).toBeInTheDocument();
  });

  it('uses Web Share API when available', () => {
    const mockShare = vi.fn();
    global.navigator.share = mockShare;

    render(<ShareButton {...defaultProps} />);
    fireEvent.click(screen.getByText('Share Score'));

    expect(mockShare).toHaveBeenCalledWith({
      title: 'Odd One Out Game',
      text: expect.stringContaining('1000 points'),
      url: defaultProps.url
    });
  });

  it('includes score in share message', () => {
    render(<ShareButton {...defaultProps} />);
    const shareButton = screen.getByText('Share Score');
    expect(shareButton).toBeInTheDocument();
    
    // Verify the message includes the score
    const expectedMessage = expect.stringContaining('1000 points');
    expect(document.body.textContent).toMatch(expectedMessage);
  });
});