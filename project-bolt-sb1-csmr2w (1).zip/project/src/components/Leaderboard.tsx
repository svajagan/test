import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, Award } from 'lucide-react';
import { Card } from '../modules/ui/components/Card';
import { Badge } from '../modules/ui/components/Badge';
import type { LeaderboardEntry } from '../lib/supabase';

type LeaderboardProps = {
  entries: LeaderboardEntry[];
  currentUserId?: string;
};

export function Leaderboard({ entries, currentUserId }: LeaderboardProps) {
  return (
    <Card className="mb-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-system-yellow dark:text-system-yellow-dark" />
          <h2 className="text-lg font-semibold">Leaderboard</h2>
        </div>
        <Badge variant="purple">Top Players</Badge>
      </div>

      <div className="space-y-3">
        {entries.map((entry, index) => (
          <motion.div
            key={entry.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`
              flex items-center justify-between p-3 rounded-xl
              ${entry.user_id === currentUserId ? 'bg-system-blue/10 dark:bg-system-blue-dark/10' : 'bg-gray-50 dark:bg-gray-800/50'}
            `}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 flex items-center justify-center">
                {index === 0 ? (
                  <Medal className="w-6 h-6 text-yellow-500" />
                ) : index === 1 ? (
                  <Medal className="w-6 h-6 text-gray-400" />
                ) : index === 2 ? (
                  <Medal className="w-6 h-6 text-amber-600" />
                ) : (
                  <span className="text-sm font-medium">{index + 1}</span>
                )}
              </div>
              <span className="font-medium">{entry.username}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold">{entry.score}</span>
              {entry.user_id === currentUserId && (
                <Badge variant="blue" className="text-xs">You</Badge>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}