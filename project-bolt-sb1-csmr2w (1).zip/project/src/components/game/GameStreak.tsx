import React from 'react';
import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';
import { Badge } from '../../modules/ui/components/Badge';

type GameStreakProps = {
  streak: number;
};

export function GameStreak({ streak }: GameStreakProps) {
  return (
    <Badge variant="purple" className="text-sm sm:text-base lg:text-lg">
      <Zap className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
      {streak}x
    </Badge>
  );
}