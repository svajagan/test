import React from 'react';
import { motion } from 'framer-motion';

type GameProgressProps = {
  timeRemaining: number;
};

export function GameProgress({ timeRemaining }: GameProgressProps) {
  return (
    <div className="absolute top-0 left-0 w-full h-2 bg-gray-100 dark:bg-gray-800 overflow-hidden rounded-t-2xl">
      <motion.div
        className="h-full bg-gradient-to-r from-system-blue via-system-purple to-system-pink dark:from-system-blue-dark dark:via-system-purple-dark dark:to-system-pink-dark"
        initial={{ width: "100%" }}
        animate={{ width: `${(timeRemaining / 30) * 100}%` }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      />
    </div>
  );
}