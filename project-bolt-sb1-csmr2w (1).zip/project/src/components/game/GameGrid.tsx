import React from 'react';
import { cn } from '../../modules/ui/utils/cn';
import { GameCard } from '../GameCard';
import type { GameSet } from '../../types/game';

type GameGridProps = {
  gameSet: GameSet;
  showHint: boolean;
  onGuess: (item: string) => void;
  isGameOver: boolean;
};

export function GameGrid({ gameSet, showHint, onGuess, isGameOver }: GameGridProps) {
  return (
    <div className={cn(
      "grid grid-cols-2",
      "gap-3 sm:gap-4 md:gap-5",
      "mb-4 sm:mb-5 relative",
      "perspective-1000",
      "transform-gpu"
    )}>
      <div 
        className={cn(
          "absolute inset-0 -m-2 sm:-m-3",
          "bg-gradient-radial from-system-blue/10 to-transparent dark:from-system-blue-dark/10",
          "pointer-events-none opacity-0 transition-opacity duration-500",
          showHint && "opacity-100"
        )}
      />
      {gameSet.items.map((item, index) => (
        <GameCard
          key={item}
          item={item}
          index={index}
          onClick={() => onGuess(item)}
          disabled={isGameOver}
          selected={showHint && item === gameSet.oddOneOut}
          correct={item === gameSet.oddOneOut && showHint}
        />
      ))}
    </div>
  );
}