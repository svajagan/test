import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../modules/ui/utils/cn';
import { GameCardBackground } from './game/GameCardBackground';
import { GameCardStatus } from './game/GameCardStatus';

type GameCardProps = {
  item: string;
  index: number;
  onClick: () => void;
  disabled: boolean;
  selected?: boolean;
  correct?: boolean;
  incorrect?: boolean;
};

export function GameCard({ 
  item, 
  index, 
  onClick, 
  disabled, 
  selected,
  correct,
  incorrect 
}: GameCardProps) {
  const getStatusColor = () => {
    if (correct) return 'border-system-green dark:border-system-green-dark';
    if (incorrect) return 'border-system-red dark:border-system-red-dark';
    if (selected) return 'border-system-blue dark:border-system-blue-dark';
    return 'border-transparent';
  };

  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: 1, 
        y: 0,
        scale: selected || correct || incorrect ? 0.98 : 1,
        rotate: correct ? 3 : incorrect ? -3 : 0,
        transition: { 
          delay: index * 0.1,
          type: "spring",
          stiffness: 400,
          damping: 30
        }
      }}
      whileHover={disabled ? {} : { 
        scale: 1.02,
        y: -4,
        transition: { duration: 0.2, type: "spring", stiffness: 400 }
      }}
      whileTap={disabled ? {} : { scale: 0.98 }}
      className={cn(
        'relative w-full aspect-square',
        'flex items-center justify-center',
        'bg-white/90 dark:bg-[#1C1C1E]/90 backdrop-blur-md',
        'rounded-2xl',
        'text-base sm:text-lg lg:text-xl font-medium',
        'border-[2.5px]',
        getStatusColor(),
        disabled ? 'opacity-50' : 'active:scale-95 hover:border-[#007AFF] dark:hover:border-[#0A84FF] hover:shadow-2xl',
        'shadow-sm transition-all duration-300 ease-out transform-gpu will-change-transform',
        'touch-manipulation no-select min-h-[80px] sm:min-h-[100px] lg:min-h-[120px]',
        'text-[#1C1C1E] dark:text-white'
      )}
      onClick={onClick}
      disabled={disabled}
      aria-pressed={selected}
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-label={`Select ${item}`}
    >
      <span className="relative z-10 px-2 py-1 sm:px-3 sm:py-2 text-center break-words leading-tight">{item}</span>
      <GameCardStatus correct={correct} incorrect={incorrect} />
      <GameCardBackground selected={selected} />
    </motion.button>
  );
}