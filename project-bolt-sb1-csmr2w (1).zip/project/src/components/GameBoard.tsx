import React from 'react';
import { motion } from 'framer-motion';
import { AnimatePresence } from 'framer-motion';
import { Category, GameSet } from '../types/game';
import { cn } from '../modules/ui/utils/cn';
import { GameTimer } from './game/GameTimer';
import { GameStreak } from './game/GameStreak';
import { GameProgress } from './game/GameProgress';
import { GameTitle } from './game/GameTitle';
import { GameGrid } from './game/GameGrid';
import { GameHint } from './game/GameHint';

type GameBoardProps = {
  category: Category;
  gameSet: GameSet;
  showHint: boolean;
  onGuess: (item: string) => void;
  isGameOver: boolean;
  timeRemaining: number;
  streak: number;
};

export function GameBoard({ 
  category, 
  gameSet, 
  showHint, 
  onGuess, 
  isGameOver,
  timeRemaining,
  streak 
}: GameBoardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className={cn(
        "relative bg-white dark:bg-[#1C1C1E]",
        "rounded-2xl",
        "p-4 sm:p-6 mb-20 will-change-transform",
        "shadow-sm mx-2 sm:mx-auto",
        "max-w-4xl w-full overflow-hidden",
        "safe-bottom safe-top"
      )}
      aria-live="polite"
      itemScope
      itemType="https://schema.org/Game"
    >
      <GameProgress timeRemaining={timeRemaining} />

      <div className="text-center mb-6 sm:mb-8">
        <GameTitle categoryName={category.name} />
        
        <div className="flex items-center justify-center gap-2 sm:gap-3 mb-2 sm:mb-3">
          <GameTimer timeRemaining={timeRemaining} />
          <GameStreak streak={streak} />
        </div>
        
        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#1D1D1F] dark:text-white mb-2">
          Find the Odd One Out
        </h1>
        <p className="text-sm sm:text-base lg:text-lg text-system-gray-1 dark:text-system-gray-dark-1">
          Select the item that doesn't belong in this set
        </p>
      </div>

      <GameGrid
        gameSet={gameSet}
        showHint={showHint}
        onGuess={onGuess}
        isGameOver={isGameOver}
      />

      <AnimatePresence>
        {showHint && (
          <GameHint hint={gameSet.hint} />
        )}
      </AnimatePresence>
    </motion.div>
  );
}