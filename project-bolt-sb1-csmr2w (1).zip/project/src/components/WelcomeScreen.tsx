import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Brain, Zap, Timer, Trophy } from 'lucide-react';
import { ThemeSelector } from './ThemeSelector';
import { cn } from '../modules/ui/utils/cn';

type WelcomeScreenProps = {
  onStart: () => void;
};

export function WelcomeScreen({ onStart }: WelcomeScreenProps) {
  return (
    <div className="min-h-[calc(100vh-4rem)]">
      <div className="relative">
        <div className="absolute inset-0 bg-white/30 dark:bg-black/30 backdrop-blur-xl" aria-hidden="true" />
        
        <div className="relative min-h-screen flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md mx-auto px-4 sm:px-6"
            itemScope
            itemType="https://schema.org/WebApplication"
          >
            <div className="text-center mb-8 sm:mb-12">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.2 }}
                className={cn(
                  "w-16 h-16 sm:w-20 sm:h-20 rounded-3xl",
                  "flex items-center justify-center mx-auto mb-4 sm:mb-6",
                  "bg-gradient-to-br from-system-blue via-system-purple to-system-pink",
                  "dark:from-system-blue-dark dark:to-system-blue-dark/80",
                  "shadow-lg"
                )}
              >
                <Brain className="w-8 h-8 sm:w-10 sm:h-10 text-white" aria-hidden="true" />
              </motion.div>
              
              <h1
                className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#1C1C1E] dark:text-white mb-2 sm:mb-3"
                itemProp="name"
              >
                1 Odd Out
              </h1>
              <p 
                className="text-sm sm:text-base text-system-gray-1 dark:text-system-gray-dark-1 max-w-sm mx-auto"
                itemProp="description"
              >
                Train Your Brain with the #1 Free Puzzle Game
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6 sm:mb-8">
              {[
                { icon: Zap, text: "Quick Thinking", label: "Feature: Quick Thinking" },
                { icon: Timer, text: "Beat the Clock", label: "Feature: Beat the Clock" },
                { icon: Trophy, text: "Build Streaks", label: "Feature: Build Streaks" },
                { icon: Brain, text: "Train Your Brain", label: "Feature: Train Your Brain" },
              ].map(({ icon: Icon, text, label }, index) => (
                <motion.div
                  key={text}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className={cn(
                    "bg-white/50 dark:bg-system-gray-dark-6/50",
                    "backdrop-blur-md p-2 sm:p-4 rounded-lg sm:rounded-2xl",
                    "flex items-center gap-2 sm:gap-3 shadow-sm"
                  )}
                  aria-label={label}
                >
                  <div className={cn(
                    "w-5 h-5 sm:w-8 sm:h-8 rounded-md sm:rounded-xl",
                    "flex items-center justify-center",
                    "bg-system-blue/10 dark:bg-system-blue-dark/10"
                  )}>
                    <Icon className="w-2.5 h-2.5 sm:w-4 sm:h-4 text-system-blue dark:text-system-blue-dark" aria-hidden="true" />
                  </div>
                  <span className="text-xs sm:text-base font-medium text-[#1C1C1E] dark:text-white">{text}</span>
                </motion.div>
              ))}
            </div>

            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              onClick={onStart}
              className={cn(
                "w-full py-3 sm:py-4 rounded-xl sm:rounded-2xl",
                "font-semibold text-base sm:text-lg shadow-lg",
                "bg-gradient-to-r from-system-blue to-system-blue/80",
                "dark:from-system-blue-dark dark:to-system-blue-dark/80",
                "text-white",
                "hover:from-system-blue/90 hover:to-system-blue/70",
                "dark:hover:from-system-blue-dark/90 dark:hover:to-system-blue-dark/70",
                "transition-all duration-200",
                "active:scale-95 transform",
                "touch-action-manipulation"
              )}
              itemProp="actionAccessibility"
              data-tour="start-button"
              aria-label="Start Playing Game"
            >
              Start Playing
            </motion.button>
          </motion.div>

          <ThemeSelector />
        </div>
      </div>
    </div>
  );
}