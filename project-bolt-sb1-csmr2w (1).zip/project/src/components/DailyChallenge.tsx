import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Trophy, Timer } from 'lucide-react';
import { format } from 'date-fns';
import { Card } from '../modules/ui/components/Card';
import { Button } from '../modules/ui/components/Button';
import { Badge } from '../modules/ui/components/Badge';

type DailyChallengeProps = {
  onStart: () => void;
  completed: boolean;
  highScore: number;
};

export function DailyChallenge({ onStart, completed, highScore }: DailyChallengeProps) {
  return (
    <Card className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-system-blue dark:text-system-blue-dark" />
          <h2 className="text-lg font-semibold">Daily Challenge</h2>
        </div>
        <Badge variant={completed ? 'green' : 'blue'}>
          {completed ? 'Completed' : 'New'}
        </Badge>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Timer className="w-4 h-4 text-system-gray-1" />
            <span>Available for: {format(new Date().setHours(23, 59, 59), 'HH:mm:ss')}</span>
          </div>
          {highScore > 0 && (
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-system-yellow dark:text-system-yellow-dark" />
              <span>Best: {highScore}</span>
            </div>
          )}
        </div>

        <Button 
          onClick={onStart}
          disabled={completed}
          className="w-full"
        >
          {completed ? 'Come back tomorrow!' : 'Start Challenge'}
        </Button>
      </div>
    </Card>
  );
}