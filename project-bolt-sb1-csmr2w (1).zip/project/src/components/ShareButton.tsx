import React from 'react';
import { Share2 } from 'lucide-react';
import { 
  WhatsappShareButton, 
  TwitterShareButton,
  TelegramShareButton,
  FacebookShareButton,
  WhatsappIcon,
  TwitterIcon,
  TelegramIcon,
  FacebookIcon
} from 'react-share';
import { Button } from '../modules/ui/components/Button';

type ShareButtonProps = {
  score: number;
  url: string;
};

export function ShareButton({ score, url }: ShareButtonProps) {
  const message = `🎮 I just scored ${score} points in Odd One Out! Can you beat my score? Play now!`;

  return (
    <div className="space-y-4">
      <Button
        variant="secondary"
        onClick={() => {
          if (navigator.share) {
            navigator.share({
              title: 'Odd One Out Game',
              text: message,
              url
            });
          }
        }}
        className="w-full"
      >
        <Share2 className="w-5 h-5 mr-2" />
        Share Score
      </Button>

      <div className="flex justify-center gap-4">
        <WhatsappShareButton url={url} title={message}>
          <WhatsappIcon size={32} round />
        </WhatsappShareButton>

        <TwitterShareButton url={url} title={message}>
          <TwitterIcon size={32} round />
        </TwitterShareButton>

        <TelegramShareButton url={url} title={message}>
          <TelegramIcon size={32} round />
        </TelegramShareButton>

        <FacebookShareButton url={url} quote={message}>
          <FacebookIcon size={32} round />
        </FacebookShareButton>
      </div>
    </div>
  );
}