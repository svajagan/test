import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Timer } from 'lucide-react';
import { useAdStore } from '../modules/ads/AdManager';
import { getAdErrorSolutions } from '../modules/ads/troubleshooting';
import { cn } from '../modules/ui/utils/cn';

type RewardedAdButtonProps = {
  onReward: () => void;
};

export function RewardedAdButton({ onReward }: RewardedAdButtonProps) {
  const { state, actions } = useAdStore();

  const handleClick = async () => {
    if (state.isLoading) return;
    
    const success = await actions.showRewardedAd();
    if (success) {
      onReward();
    }
  };

  const getTimeRemaining = () => {
    if (!state.lastRewardTime) return 0;
    const elapsed = Date.now() - state.lastRewardTime;
    const remaining = Math.max(0, 5 * 60 - Math.floor(elapsed / 1000));
    return remaining;
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const timeRemaining = getTimeRemaining();
  const canWatchAd = !state.lastRewardTime || timeRemaining === 0;

  return (
    <>
      <motion.button
        whileHover={canWatchAd && !state.isLoading ? { scale: 1.02 } : {}}
        whileTap={canWatchAd && !state.isLoading ? { scale: 0.98 } : {}}
        onClick={handleClick}
        disabled={state.isLoading || !canWatchAd}
        className={cn(
          "flex items-center justify-center gap-2",
          "w-full px-4 py-3 rounded-xl",
          "bg-system-green dark:bg-system-green-dark",
          "text-white font-medium",
          "transition-colors duration-200",
          (state.isLoading || !canWatchAd) && "opacity-50 cursor-not-allowed"
        )}
      >
        {state.isLoading ? (
          <span>Loading Video...</span>
        ) : canWatchAd ? (
          <>
            <Heart className="w-5 h-5" />
            <span>Watch Ad for Extra Life</span>
          </>
        ) : (
          <>
            <Timer className="w-5 h-5" />
            <span>Wait {formatTime(timeRemaining)}</span>
          </>
        )}
      </motion.button>

      {state.error && (
        <>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-system-red dark:text-system-red-dark text-sm text-center mt-2"
          >
            {state.error}
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 space-y-2"
          >
            <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Try these solutions:</p>
            <ul className="text-sm space-y-1 text-gray-500 dark:text-gray-500">
              {getAdErrorSolutions('NETWORK_ERROR').map((solution, index) => (
                <li key={index} className="flex items-center gap-2">
                  <span className="w-1 h-1 rounded-full bg-gray-400" />
                  {solution}
                </li>
              ))}
            </ul>
          </motion.div>
        </>
      )}
    </>
  );
}