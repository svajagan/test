import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Achievement } from '../modules/game/types';
import { cn } from '../modules/ui/utils/cn';

type AchievementPopupProps = {
  achievement: Achievement | null;
  onClaim: () => void;
};

export function AchievementPopup({ achievement, onClaim }: AchievementPopupProps) {
  if (!achievement) return null;

  const Icon = achievement.icon;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className={cn(
          "fixed bottom-4 left-1/2 -translate-x-1/2",
          "max-w-sm w-full mx-4",
          "bg-white dark:bg-[#1C1C1E]",
          "rounded-2xl shadow-lg",
          "p-4 space-y-4",
          "border border-system-gray-5 dark:border-system-gray-dark-5"
        )}
      >
        <div className="flex items-center gap-4">
          <div className={cn(
            "w-12 h-12 rounded-xl",
            "bg-system-blue/10 dark:bg-system-blue-dark/10",
            "flex items-center justify-center"
          )}>
            <Icon className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
          </div>
          <div>
            <h3 className="font-semibold text-lg dark:text-white">
              {achievement.name}
            </h3>
            <p className="text-sm text-system-gray-1 dark:text-system-gray-dark-1">
              {achievement.description}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-system-gray-1 dark:text-system-gray-dark-1">
              Reward:
            </span>
            <span className="text-sm font-semibold text-system-blue dark:text-system-blue-dark">
              {achievement.reward.type === 'extra_life' && `+${achievement.reward.value} Life`}
              {achievement.reward.type === 'hint' && `+${achievement.reward.value} Hints`}
              {achievement.reward.type === 'time_bonus' && `+${achievement.reward.value}s Time`}
              {achievement.reward.type === 'score_multiplier' && `${achievement.reward.value}x Score`}
            </span>
          </div>
          <button
            onClick={onClaim}
            className={cn(
              "px-4 py-2 rounded-xl text-sm font-medium",
              "bg-system-blue dark:bg-system-blue-dark",
              "text-white",
              "hover:bg-system-blue/90 dark:hover:bg-system-blue-dark/90",
              "transition-colors duration-200"
            )}
          >
            Claim Reward
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}