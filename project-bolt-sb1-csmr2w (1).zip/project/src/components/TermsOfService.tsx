import React from 'react';
import { Card } from '../modules/ui/components/Card';
import { FileText, Shield, AlertCircle, Scale, Heart, Mail } from 'lucide-react';

export function TermsOfService() {
  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-4">Terms of Service</h1>
        <p className="text-gray-600 dark:text-gray-400">Last updated: March 18, 2024</p>
      </div>

      <Card className="space-y-6">
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <FileText className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Agreement to Terms</h2>
          </div>
          <p>
            By accessing or using 1 Odd Out, you agree to be bound by these Terms of Service. If you disagree with any part of these terms, you may not access or use our services.
          </p>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Intellectual Property Rights</h2>
          </div>
          <div className="space-y-2">
            <p>
              1 Odd Out and its original content, features, and functionality are owned by us and are protected by international copyright, trademark, patent, trade secret, and other intellectual property laws.
            </p>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">User Responsibilities</h2>
          </div>
          <div className="space-y-2">
            <p>When using our services, you agree to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Provide accurate information when required</li>
              <li>Use the service for its intended purpose</li>
              <li>Not attempt to circumvent any security measures</li>
              <li>Not engage in any harmful or disruptive behavior</li>
            </ul>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Scale className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Limitation of Liability</h2>
          </div>
          <p>
            1 Odd Out shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use or inability to use the service.
          </p>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Heart className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Fair Usage</h2>
          </div>
          <div className="space-y-2">
            <p>We expect users to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Play fairly and not use automated tools or cheats</li>
              <li>Respect other players and maintain good sportsmanship</li>
              <li>Report any bugs or issues they encounter</li>
              <li>Not share or sell account information</li>
            </ul>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Mail className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Contact Information</h2>
          </div>
          <p>
            For any questions about these Terms of Service, please contact us at terms@1oddout.com
          </p>
        </section>

        <section className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            We reserve the right to modify these terms at any time. We will notify users of any changes by updating the date at the top of this page.
          </p>
        </section>
      </Card>
    </div>
  );
}