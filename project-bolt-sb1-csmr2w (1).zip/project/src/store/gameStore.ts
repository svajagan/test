import { create } from 'zustand';
import { GameState, GameResult } from '../types/game';
import { getRandomCategory, getRandomSet } from '../modules/game/utils/generators';
import { calculateTimeLimit } from '../modules/game/utils/scoring';

const INITIAL_STATE: GameState = {
  score: 0,
  currentLevel: 1,
  lives: 3,
  gameOver: false,
  hintsRemaining: 3,
  currentStreak: 0,
  bestStreak: 0,
  timeRemaining: 30,
  showHint: false,
  gameStarted: false,
  lastResult: null,
  difficulty: 'EASY',
  totalGamesPlayed: 0,
  highScores: [],
  timeBonus: 0,
  streakBonus: 0,
  difficultyBonus: 0,
  achievements: []
};

export const useGameStore = create<{
  state: GameState;
  actions: {
    startGame: () => void;
    makeGuess: (item: string) => void;
    useHint: () => void;
    resetGame: () => void;
    updateTimer: () => void;
    addLife: () => void;
    resumeGame: () => void;
  };
}>((set, get) => ({
  state: INITIAL_STATE,
  actions: {
    startGame: () => {
      const category = getRandomCategory();
      const gameSet = getRandomSet(category);
      set({
        state: {
          ...INITIAL_STATE,
          gameStarted: true,
          currentCategory: category,
          currentSet: gameSet,
        },
      });
    },
    makeGuess: (item: string) => {
      const { state } = get();
      if (!state.currentSet || !state.currentCategory) return;

      const isCorrect = state.currentSet.oddOneOut === item;

      if (isCorrect) {
        const category = getRandomCategory();
        const gameSet = getRandomSet(category);
        const timeBonus = Math.ceil(state.timeRemaining * 10);
        const streakBonus = state.currentStreak * 50;
        
        set({
          state: {
            ...state,
            score: state.score + timeBonus + streakBonus,
            currentLevel: state.currentLevel + 1,
            currentStreak: state.currentStreak + 1,
            bestStreak: Math.max(state.currentStreak + 1, state.bestStreak),
            timeRemaining: calculateTimeLimit(state.currentLevel + 1, state.difficulty),
            currentCategory: category,
            currentSet: gameSet,
            showHint: false,
            lastResult: { correct: true, bonus: streakBonus },
          },
        });
      } else {
        const newLives = state.lives - 1;
        set({
          state: {
            ...state,
            lives: newLives,
            gameOver: newLives === 0,
            currentStreak: 0,
            showHint: false,
            lastResult: { correct: false, mistake: item },
          },
        });
      }
    },
    useHint: () => {
      const { state } = get();
      if (state.hintsRemaining > 0) {
        set({
          state: {
            ...state,
            hintsRemaining: state.hintsRemaining - 1,
            showHint: true,
          },
        });
      }
    },
    resetGame: () => {
      const category = getRandomCategory();
      const gameSet = getRandomSet(category);
      set({
        state: {
          ...INITIAL_STATE,
          gameStarted: true,
          currentCategory: category,
          currentSet: gameSet,
        },
      });
    },
    updateTimer: () => {
      const { state } = get();
      if (!state.gameOver && state.gameStarted && state.timeRemaining > 0) {
        const newTimeRemaining = Math.max(0, state.timeRemaining - 0.1);
        set({
          state: {
            ...state,
            timeRemaining: newTimeRemaining,
            gameOver: newTimeRemaining === 0,
          },
        });
      }
    },
    addLife: () => {
      const { state } = get();
      set({
        state: {
          ...state,
          lives: state.lives + 1,
        },
      });
    },
    resumeGame: () => {
      const { state } = get();
      set({
        state: {
          ...state,
          gameOver: false,
          timeRemaining: calculateTimeLimit(state.currentLevel, state.difficulty),
        },
      });
    },
  },
}));