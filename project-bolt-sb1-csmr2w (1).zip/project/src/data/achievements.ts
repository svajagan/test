import { Achievement } from '../modules/game/types';
import { Trophy, Zap, Clock, Heart, Star, Target, Award } from 'lucide-react';

export const achievements: Achievement[] = [
  {
    id: 'quick_thinker',
    name: 'Quick Thinker',
    description: 'Complete 3 rounds with more than 20 seconds remaining',
    icon: Clock,
    reward: {
      type: 'time_bonus',
      value: 10
    }
  },
  {
    id: 'perfect_streak',
    name: 'Perfect Streak',
    description: 'Maintain a 5x streak without using hints',
    icon: Zap,
    reward: {
      type: 'score_multiplier',
      value: 2
    }
  },
  {
    id: 'survivor',
    name: 'Survivor',
    description: 'Complete 10 rounds without losing a life',
    icon: Heart,
    reward: {
      type: 'extra_life',
      value: 1
    }
  },
  {
    id: 'master_puzzler',
    name: 'Master Puzzler',
    description: 'Reach level 20 in a single game',
    icon: Trophy,
    reward: {
      type: 'hint',
      value: 3
    }
  },
  {
    id: 'speed_demon',
    name: 'Speed Demon',
    description: 'Answer correctly within 3 seconds 5 times',
    icon: Star,
    reward: {
      type: 'time_bonus',
      value: 15
    }
  },
  {
    id: 'precision_master',
    name: 'Precision Master',
    description: 'Get 10 correct answers in a row',
    icon: Target,
    reward: {
      type: 'score_multiplier',
      value: 3
    }
  },
  {
    id: 'grand_master',
    name: 'Grand Master',
    description: 'Score over 10,000 points in a single game',
    icon: Award,
    reward: {
      type: 'extra_life',
      value: 2
    }
  }
];