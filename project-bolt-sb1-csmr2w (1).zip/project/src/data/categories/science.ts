import { Category, Difficulty } from '../../types/game';

export const scienceCategory: Category = {
  name: 'Science & Innovation',
  difficulty: Difficulty.Hard,
  sets: [
    {
      items: ['📚 Shakespeare', '💡 Edison', '⚡ Tesla', '🍎 Newton'],
      oddOneOut: '📚 Shakespeare',
      explanation: 'Shakespeare was a playwright, others were inventors/scientists.',
      hint: 'Think about scientific contributions.',
    },
    {
      items: ['⭐ Star', '🌈 Rainbow', '🌍 Planet', '☄️ Asteroid'],
      oddOneOut: '🌈 Rainbow',
      explanation: 'Rainbow is an atmospheric phenomenon, others are celestial objects.',
      hint: 'Consider objects in space.',
    },
    {
      items: ['🔭 Telescope', '🎨 Kaleidoscope', '🔬 Microscope', '📊 Spectroscope'],
      oddOneOut: '🎨 Kaleidoscope',
      explanation: 'Kaleidoscope is a toy, others are scientific instruments.',
      hint: 'Which is used for entertainment?',
    },
    {
      items: ['🧬 RNA', '📄 PDF', '🧬 DNA', '⚡ ATP'],
      oddOneOut: '📄 PDF',
      explanation: 'PDF is a file format, others are biological molecules.',
      hint: 'Think about biology.',
    },
    {
      items: ['⚛️ Neutron', '🖍️ Crayon', '⚛️ Proton', '⚛️ Electron'],
      oddOneOut: '🖍️ Crayon',
      explanation: 'Crayon is an art supply, others are subatomic particles.',
      hint: 'Consider atomic structure.',
    }
  ]
};