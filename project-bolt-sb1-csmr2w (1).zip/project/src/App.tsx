import React, { useEffect } from 'react';
import { Routes, Route, Link, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { ClarityProvider } from './modules/analytics/MicrosoftClarity';
import { GameBoard } from './components/GameBoard';
import { GameHeader } from './components/GameHeader';
import { GameOver } from './components/GameOver';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ThemeSelector } from './components/ThemeSelector';
import { PrivacyPolicy } from './components/PrivacyPolicy';
import { TermsOfService } from './components/TermsOfService';
import AboutPage from './pages/AboutPage';
import HowToPlayPage from './pages/HowToPlayPage';
import { Footer } from './components/Footer';
import { useGameStore } from './store/gameStore';
import { useAdStore } from './modules/ads/AdManager';
import { cn } from './modules/ui/utils/cn';
import { trackGameStart, trackGameOver, trackLevelComplete } from './modules/analytics/AnalyticsManager';
import { optimizeAnimationFrame } from './modules/game/utils/performance';

export default function App() {
  const { state, actions } = useGameStore();
  const { actions: adActions } = useAdStore();

  useEffect(() => {
    adActions.initializeAds();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      optimizeAnimationFrame(actions.updateTimer);
    }, 100);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (state.gameStarted) {
      trackGameStart();
    }
  }, [state.gameStarted]);

  useEffect(() => {
    if (state.gameOver) {
      trackGameOver(state);
    }
  }, [state.gameOver]);

  useEffect(() => {
    if (state.lastResult?.correct) {
      trackLevelComplete(state.currentLevel, state.score);
    }
  }, [state.currentLevel]);

  const handleContinue = () => {
    actions.addLife();
    actions.resumeGame();
  };

  return (
    <ClarityProvider>
      <div className="min-h-screen flex flex-col bg-gradient-to-b from-[var(--theme-base)] to-white/95 dark:to-black/95">
        <header className="sticky top-0 z-50 bg-white/50 dark:bg-black/50 backdrop-blur-md border-b border-gray-200/50 dark:border-gray-800/50">
          <nav className="max-w-4xl mx-auto px-4 h-16 flex justify-between items-center" aria-label="Main navigation">
            <Link to="/" className="text-xl font-bold text-system-blue dark:text-system-blue-dark">
              1 Odd Out
            </Link>
            <ul className="flex items-center space-x-6">
              <li>
                <Link to="/how-to-play" className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white">
                  How to Play
                </Link>
              </li>
            </ul>
          </nav>
        </header>
        <main className="flex-1 relative">
          <h1 className="sr-only">1 Odd Out - Brain Training Puzzle Game</h1>
              <Routes>
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/terms" element={<TermsOfService />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/how-to-play" element={<HowToPlayPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
                <Route path="/" element={
                  <main>
                    {!state.gameStarted ? (
                      <WelcomeScreen onStart={actions.startGame} />
                    ) : (
                      <div className="max-w-4xl mx-auto p-4 space-y-6">
                      <GameHeader
                        score={state.score}
                        lives={state.lives}
                        level={state.currentLevel}
                        timeRemaining={state.timeRemaining}
                        currentStreak={state.currentStreak}
                        hintsRemaining={state.hintsRemaining}
                        onUseHint={actions.useHint}
                      />
                      
                      <AnimatePresence mode="wait">
                        {state.currentCategory && state.currentSet && (
                          <GameBoard
                            category={state.currentCategory}
                            gameSet={state.currentSet}
                            showHint={state.showHint}
                            onGuess={actions.makeGuess}
                            isGameOver={state.gameOver}
                            timeRemaining={state.timeRemaining}
                            streak={state.currentStreak}
                          />
                        )}
                      </AnimatePresence>

                      <AnimatePresence>
                        {state.gameOver && (
                          <GameOver
                            score={state.score}
                            bestStreak={state.bestStreak}
                            level={state.currentLevel}
                            timeBonus={state.timeBonus}
                            streakBonus={state.streakBonus}
                            difficultyBonus={state.difficultyBonus}
                            onRestart={actions.resetGame}
                            onContinue={handleContinue}
                          />
                        )}
                      </AnimatePresence>
                      </div>
                    )}
                  </main>
                } />
              </Routes>

              <ThemeSelector />
            </main>
          <footer className="sticky bottom-0 z-50 bg-white/50 dark:bg-black/50 backdrop-blur-md border-t border-gray-200/50 dark:border-gray-800/50">
            <nav className="max-w-4xl mx-auto px-4 h-16 flex justify-between items-center" aria-label="Footer Navigation">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                © 2024 1 Odd Out
              </div>
              <ul className="flex items-center gap-6">
                <li>
                  <Link to="/how-to-play" className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors">
                    How to Play
                  </Link>
                </li>
                <li>
                  <Link to="/privacy" className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors">
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link to="/terms" className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors">
                    Terms
                  </Link>
                </li>
              </ul>
            </nav>
          </footer>
      </div>
    </ClarityProvider>
  );
}