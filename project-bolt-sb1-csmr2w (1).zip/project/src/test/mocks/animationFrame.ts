import { vi } from 'vitest';

export function mockAnimationFrame() {
  let lastTime = 0;

  window.requestAnimationFrame = vi.fn((callback) => {
    const currentTime = Date.now();
    const timeToCall = Math.max(0, 16 - (currentTime - lastTime));
    const id = window.setTimeout(() => callback(currentTime + timeToCall), timeToCall);
    lastTime = currentTime + timeToCall;
    return id;
  });

  window.cancelAnimationFrame = vi.fn((id) => {
    clearTimeout(id);
  });
}