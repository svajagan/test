import '@testing-library/jest-dom';
import { vi } from 'vitest';
import { mockAnimationFrame } from './mocks/animationFrame';
import { mockMatchMedia } from './mocks/matchMedia';

// Setup mock for requestAnimationFrame and cancelAnimationFrame
mockAnimationFrame();

// Setup mock for matchMedia
mockMatchMedia();

// Mock framer-motion
vi.mock('framer-motion', () => ({
  motion: {
    button: ({ children, ...props }: any) => <button {...props}>{children}</button>,
    div: ({ children, ...props }: any) => <div {...props}>{children}</div>,
  },
  AnimatePresence: ({ children }: any) => <>{children}</>,
}));