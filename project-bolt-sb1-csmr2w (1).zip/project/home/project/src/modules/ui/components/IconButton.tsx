import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../utils/cn';

type IconButtonProps = {
  icon: React.ElementType;
  variant?: 'primary' | 'secondary' | 'success' | 'danger';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

export function IconButton({
  icon: Icon,
  variant = 'primary',
  className,
  size = 'md',
  disabled,
  ...props
}: IconButtonProps) {
  const sizes = {
    sm: 'w-10 h-10 sm:w-8 sm:h-8',
    md: 'w-12 h-12 sm:w-10 sm:h-10',
    lg: 'w-14 h-14 sm:w-12 sm:h-12'
  };

  const iconSizes = {
    sm: 'w-5 h-5 sm:w-4 sm:h-4',
    md: 'w-6 h-6 sm:w-5 sm:h-5',
    lg: 'w-7 h-7 sm:w-6 sm:h-6'
  };

  const variants = {
    primary: 'bg-[#007AFF]/10 text-[#007AFF] hover:bg-[#007AFF]/20 dark:bg-[#0A84FF]/20 dark:text-[#0A84FF]',
    secondary: 'bg-[#8E8E93]/10 text-[#8E8E93] hover:bg-[#8E8E93]/20 dark:bg-[#98989D]/20 dark:text-[#98989D]',
    success: 'bg-[#34C759]/10 text-[#34C759] hover:bg-[#34C759]/20 dark:bg-[#30D158]/20 dark:text-[#30D158]',
    danger: 'bg-[#FF3B30]/10 text-[#FF3B30] hover:bg-[#FF3B30]/20 dark:bg-[#FF453A]/20 dark:text-[#FF453A]'
  };

  return (
    <motion.button
      whileTap={disabled ? {} : { scale: 0.95 }}
      className={cn(
        'rounded-2xl flex items-center justify-center',
        variants[variant],
        'transition-colors duration-200',
        'touch-manipulation',
        disabled && 'opacity-50 cursor-not-allowed',
        sizes[size],
        className
      )}
      disabled={disabled}
      {...props}
    >
      <Icon className={iconSizes[size]} />
    </motion.button>
  );
}