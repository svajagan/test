import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { GameCard } from '../GameCard';

describe('GameCard', () => {
  const defaultProps = {
    item: 'Test Item',
    index: 0,
    onClick: vi.fn(),
    disabled: false,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders item text correctly', () => {
    render(<GameCard {...defaultProps} />);
    expect(screen.getByText('Test Item')).toBeInTheDocument();
  });

  it('handles click events when enabled', () => {
    const onClick = vi.fn();
    render(<GameCard {...defaultProps} onClick={onClick} />);
    
    fireEvent.click(screen.getByRole('button'));
    expect(onClick).toHaveBeenCalledOnce();
  });

  it('prevents click events when disabled', () => {
    const onClick = vi.fn();
    render(<GameCard {...defaultProps} onClick={onClick} disabled />);
    
    fireEvent.click(screen.getByRole('button'));
    expect(onClick).not.toHaveBeenCalled();
  });

  it('applies selected styles when selected prop is true', () => {
    render(<GameCard {...defaultProps} selected />);
    const button = screen.getByRole('button');
    expect(button).toHaveClass('border-[#007AFF]');
    expect(button).toHaveAttribute('aria-pressed', 'true');
  });

  it('applies disabled styles when disabled prop is true', () => {
    render(<GameCard {...defaultProps} disabled />);
    const button = screen.getByRole('button');
    expect(button).toHaveClass('opacity-50', 'cursor-not-allowed');
    expect(button).toBeDisabled();
  });

  it('applies dark mode classes correctly', () => {
    render(<GameCard {...defaultProps} />);
    const button = screen.getByRole('button');
    expect(button).toHaveClass('dark:bg-[#1C1C1E]');
    expect(button).toHaveClass('dark:text-white');
    expect(button).toHaveClass('dark:hover:border-[#0A84FF]');
  });

  it('renders with correct responsive text classes', () => {
    render(<GameCard {...defaultProps} />);
    const button = screen.getByRole('button');
    expect(button).toHaveClass('text-lg', 'sm:text-xl', 'md:text-2xl');
  });
});