import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../utils/cn';

type BadgeProps = {
  variant?: 'blue' | 'gray' | 'green' | 'red' | 'orange' | 'purple';
  children: React.ReactNode;
  className?: string;
  animate?: boolean;
} & React.HTMLAttributes<HTMLDivElement>;

export function Badge({ 
  variant = 'blue',
  children, 
  className, 
  animate = true,
  ...props 
}: BadgeProps) {
  const Component = animate ? motion.div : 'div';

  const variants = {
    blue: 'bg-[#007AFF]/10 text-[#007AFF] dark:bg-[#0A84FF]/20 dark:text-[#0A84FF]',
    gray: 'bg-[#8E8E93]/10 text-[#8E8E93] dark:bg-[#98989D]/20 dark:text-[#98989D]',
    green: 'bg-[#34C759]/10 text-[#34C759] dark:bg-[#30D158]/20 dark:text-[#30D158]',
    red: 'bg-[#FF3B30]/10 text-[#FF3B30] dark:bg-[#FF453A]/20 dark:text-[#FF453A]',
    orange: 'bg-[#FF9500]/10 text-[#FF9500] dark:bg-[#FF9F0A]/20 dark:text-[#FF9F0A]',
    purple: 'bg-[#AF52DE]/10 text-[#AF52DE] dark:bg-[#BF5AF2]/20 dark:text-[#BF5AF2]'
  };

  return (
    <Component
      initial={animate ? { scale: 0.9 } : undefined}
      animate={animate ? { scale: 1 } : undefined}
      className={cn(
        'inline-flex items-center justify-center',
        'px-4 py-2 text-sm sm:text-base',
        'rounded-full font-medium',
        'touch-manipulation',
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </Component>
  );
}